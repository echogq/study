var text = null;
var qrcode = null;
$(function () {
	// http://testconsole.icfqs.com:7615/site/app/zbshare/zb/detail.html?
	var dataID = getUrlParam("id");
	var flag = getUrlParam("f");
	var host = getUrlParam("host");
	text = "http://" + "mbser.tdx.com.cn:7615" + "/site/webApp/app/zbshare/zb/detail.html?f=" + flag + "&id=" + dataID;
	$('#qrUrl').val(text);
	qrcode = new QRCode("qrcode", {
	    width: 150,
	    height: 150,
	    colorDark : "#000000",
	    colorLight : "#ffffff",
	    correctLevel : QRCode.CorrectLevel.H
	});

	wxqrcode = new QRCode("wxqrcode", {
	    width: 150,
	    height: 150,
	    colorDark : "#000000",
	    colorLight : "#ffffff",
	    correctLevel : QRCode.CorrectLevel.H
	});

    $(".copy_btn").zclip({
		path: "lib/ZeroClipboard.swf",
		copy: function(){
			return $('#qrUrl').val();
		},
		afterCopy:function(){			/* 复制成功后的操作 */
			var $copysuc = $("<div class='copy-tips'><div class='copy-tips-wrap'>☺ 复制成功</div></div>");
			$("body").find(".copy-tips").remove().end().append($copysuc);
			$(".copy-tips").fadeOut(3000);
        }
	});

    // bootstrap 提示工具
	$("[data-toggle='tooltip']").tooltip();

    // 第三方分享插件初始化
	$("#socialShare").socialShare({
		content: $("p").text().trim(),
		url: $('#qrUrl').val(),
		title: ' '
		// titile: $("h1").text().trim()
	});

	$(".msb_main").trigger('click');
})

// tdx软件扫描
function obtTDX () {
	qrcode.makeCode(text);
	$('#QRModal').modal({
		keyboard: true
	})
}

function obtWX () {
	wxqrcode.makeCode(text);
	/*var wxqrcode = new QRCode(document.getElementById("wxqrcode"), {
		text: "http://jindo.dev.naver.com/collie",
		width: 128,
		height: 128,
		colorDark : "#000000",
		colorLight : "#ffffff",
		correctLevel : QRCode.CorrectLevel.H
	});*/

	$('#WXModal').modal({
		keyboard: true
	})
}



function obtQQ () {
	var p = {
	    url: $('#qrUrl').val(), /*获取URL，可加上来自分享到QQ标识，方便统计*/
	    desc: "加点评论吧...", 
	    title: "通达信", /*分享标题(可选)*/
	    summary: "通达信就是趋势,趋势造就财富", /*分享摘要(可选)*/
	    pics: "lib/tdx.png", /*分享图片(可选)*/
	    style: "203",
	    width: 16,
	    height: 16
    };
    var s = [];
    for(var i in p){
        s.push(i + '=' + encodeURIComponent(p[i] || ''));
    }
    var qhref = "http://connect.qq.com/widget/shareqq/index.html?" + s.join('&');
    $(".qq").attr({href:qhref,target:"_blank"});
}


// 获取URL中的参数
function getUrlParam(name)
{
  var reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)");
  var url = (window.location.search || window.location.hash);
  var r = url.substr(url.indexOf('?') + 1).match(reg);
  if (r!=null) return decodeURIComponent(r[2]); return null; 
}
